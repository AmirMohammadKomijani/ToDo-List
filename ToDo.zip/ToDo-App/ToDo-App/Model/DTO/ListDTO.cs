﻿namespace ToDo_App.Model.DTO
{
    public class ListDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
