﻿namespace ToDo_App.Model.DTO
{
    public class ListUpdateDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
